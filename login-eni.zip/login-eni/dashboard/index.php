<?php
session_start();
require_once __DIR__ . '/../config/database.php';

// Proteksi Halaman: Jika belum login, tendang ke login.php
if (!isset($_SESSION['user_id'])) {
    header("Location: ../auth/login.php");
    exit();
}

$message = '';
$message_type = '';

// --- PROSES CRUD ---

// 1. Tambah Data (Create)
if (isset($_POST['action']) && $_POST['action'] === 'create') {
    $nama_produk = trim($_POST['nama_produk']);
    $kategori    = trim($_POST['kategori']);
    $harga       = floatval($_POST['harga']);
    $stok        = intval($_POST['stok']);

    if (!empty($nama_produk) && !empty($kategori)) {
        $stmt = $conn->prepare("INSERT INTO produk (nama_produk, kategori, harga, stok) VALUES (:nama, :kategori, :harga, :stok)");
        $stmt->execute([
            'nama'     => $nama_produk,
            'kategori' => $kategori,
            'harga'    => $harga,
            'stok'     => $stok
        ]);
        $_SESSION['msg'] = 'Produk berhasil ditambahkan!';
        $_SESSION['msg_type'] = 'success';
        header("Location: index.php");
        exit();
    }
}

// 2. Edit Data (Update)
if (isset($_POST['action']) && $_POST['action'] === 'update') {
    $id          = intval($_POST['id']);
    $nama_produk = trim($_POST['nama_produk']);
    $kategori    = trim($_POST['kategori']);
    $harga       = floatval($_POST['harga']);
    $stok        = intval($_POST['stok']);

    if ($id && !empty($nama_produk)) {
        $stmt = $conn->prepare("UPDATE produk SET nama_produk = :nama, kategori = :kategori, harga = :harga, stok = :stok WHERE id = :id");
        $stmt->execute([
            'nama'     => $nama_produk,
            'kategori' => $kategori,
            'harga'    => $harga,
            'stok'     => $stok,
            'id'       => $id
        ]);
        $_SESSION['msg'] = 'Produk berhasil diperbarui!';
        $_SESSION['msg_type'] = 'success';
        header("Location: index.php");
        exit();
    }
}

// 3. Hapus Data (Delete)
if (isset($_GET['delete'])) {
    $id = intval($_GET['delete']);
    $stmt = $conn->prepare("DELETE FROM produk WHERE id = :id");
    $stmt->execute(['id' => $id]);
    $_SESSION['msg'] = 'Produk berhasil dihapus!';
    $_SESSION['msg_type'] = 'danger';
    header("Location: index.php");
    exit();
}

// Pesan Notifikasi Session
if (isset($_SESSION['msg'])) {
    $message = $_SESSION['msg'];
    $message_type = $_SESSION['msg_type'];
    unset($_SESSION['msg']);
    unset($_SESSION['msg_type']);
}

// Ambil Data Produk yang ingin di-edit
$edit_data = null;
if (isset($_GET['edit'])) {
    $edit_id = intval($_GET['edit']);
    $stmt = $conn->prepare("SELECT * FROM produk WHERE id = :id");
    $stmt->execute(['id' => $edit_id]);
    $edit_data = $stmt->fetch(PDO::FETCH_ASSOC);
}

// 4. Baca Data (Read)
$stmt = $conn->prepare("SELECT * FROM produk ORDER BY id DESC");
$stmt->execute();
$produk_list = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard - Login ENI</title>
    <link rel="stylesheet" href="../assets/css/style.css">
</head>

<body class="dashboard-layout">

    <!-- Sidebar Navigation -->
    <aside class="sidebar">
        <div class="sidebar-header">
            <h3>Login ENI</h3>
        </div>
        <ul class="sidebar-menu">
            <li class="active"><a href="index.php">📊 Dashboard & CRUD</a></li>
            <li><a href="../auth/logout.php" onclick="return confirm('Apakah Anda yakin ingin keluar?');">🚪 Logout</a></li>
        </ul>
        <div class="sidebar-footer">
            <p>Login sebagai:<br><strong><?= htmlspecialchars($_SESSION['nama_lengkap']) ?></strong></p>
        </div>
    </aside>

    <!-- Content Area Utama -->
    <main class="main-content">
        <header class="topbar">
            <h2>Dashboard Panel</h2>
            <div class="user-info">
                Selamat Datang, <strong><?= htmlspecialchars($_SESSION['username']) ?></strong>
            </div>
        </header>

        <div class="content-body">

            <?php if ($message): ?>
                <div class="alert alert-<?= $message_type ?>">
                    <?= htmlspecialchars($message) ?>
                </div>
            <?php endif; ?>

            <!-- Form CRUD (Tambah / Edit Produk) -->
            <div class="card">
                <div class="card-header">
                    <h3><?= $edit_data ? '✏️ Edit Produk' : '➕ Tambah Produk Baru' ?></h3>
                </div>
                <div class="card-body">
                    <form action="index.php" method="POST">
                        <input type="hidden" name="action" value="<?= $edit_data ? 'update' : 'create' ?>">
                        <?php if ($edit_data): ?>
                            <input type="hidden" name="id" value="<?= $edit_data['id'] ?>">
                        <?php endif; ?>

                        <div class="form-row">
                            <div class="form-group col">
                                <label for="nama_produk">Nama Produk</label>
                                <input type="text" name="nama_produk" id="nama_produk" value="<?= $edit_data ? htmlspecialchars($edit_data['nama_produk']) : '' ?>" placeholder="Masukkan nama produk" required>
                            </div>
                            <div class="form-group col">
                                <label for="kategori">Kategori</label>
                                <input type="text" name="kategori" id="kategori" value="<?= $edit_data ? htmlspecialchars($edit_data['kategori']) : '' ?>" placeholder="Kategori (misal: Elektronik)" required>
                            </div>
                        </div>

                        <div class="form-row">
                            <div class="form-group col">
                                <label for="harga">Harga (Rp)</label>
                                <input type="number" step="0.01" name="harga" id="harga" value="<?= $edit_data ? htmlspecialchars($edit_data['harga']) : '' ?>" placeholder="0" required>
                            </div>
                            <div class="form-group col">
                                <label for="stok">Stok</label>
                                <input type="number" name="stok" id="stok" value="<?= $edit_data ? htmlspecialchars($edit_data['stok']) : '' ?>" placeholder="0" required>
                            </div>
                        </div>

                        <div class="form-actions">
                            <button type="submit" class="btn btn-primary"><?= $edit_data ? 'Update Produk' : 'Simpan Produk' ?></button>
                            <?php if ($edit_data): ?>
                                <a href="index.php" class="btn btn-secondary">Batal</a>
                            <?php endif; ?>
                        </div>
                    </form>
                </div>
            </div>

            <!-- Tabel Menampilkan Data Produk -->
            <div class="card" style="margin-top: 25px;">
                <div class="card-header">
                    <h3>📦 Daftar Produk</h3>
                </div>
                <div class="card-body">
                    <table class="table">
                        <thead>
                            <tr>
                                <th>No</th>
                                <th>Nama Produk</th>
                                <th>Kategori</th>
                                <th>Harga</th>
                                <th>Stok</th>
                                <th>Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (count($produk_list) > 0): ?>
                                <?php foreach ($produk_list as $index => $item): ?>
                                    <tr>
                                        <td><?= $index + 1 ?></td>
                                        <td><?= htmlspecialchars($item['nama_produk']) ?></td>
                                        <td><?= htmlspecialchars($item['kategori']) ?></td>
                                        <td>Rp <?= number_format($item['harga'], 0, ',', '.') ?></td>
                                        <td><?= htmlspecialchars($item['stok']) ?></td>
                                        <td>
                                            <a href="index.php?edit=<?= $item['id'] ?>" class="btn-sm btn-edit">Edit</a>
                                            <a href="index.php?delete=<?= $item['id'] ?>" class="btn-sm btn-delete" onclick="return confirm('Yakin ingin menghapus data ini?');">Hapus</a>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php else: ?>
                                <tr>
                                    <td colspan="6" style="text-align: center; color: #64748b;">Belum ada data produk. Silakan tambahkan melalui form di atas.</td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>

        </div>
    </main>

</body>

</html>
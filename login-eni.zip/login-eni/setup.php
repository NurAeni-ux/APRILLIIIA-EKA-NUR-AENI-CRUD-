<?php
$host = "localhost";
$user = "root";
$pass = ""; // Password default Laragon biasanya kosong

try {
    // 1. Koneksi ke MySQL
    $conn = new PDO("mysql:host=$host;charset=utf8", $user, $pass);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // 2. Buat Database
    $conn->exec("CREATE DATABASE IF NOT EXISTS `db_login_eni`");
    $conn->exec("USE `db_login_eni`");

    // 3. Buat Tabel Users
    $sqlUsers = "CREATE TABLE IF NOT EXISTS `users` (
        `id` INT AUTO_INCREMENT PRIMARY KEY,
        `username` VARCHAR(50) NOT NULL UNIQUE,
        `password` VARCHAR(255) NOT NULL,
        `nama_lengkap` VARCHAR(100) NOT NULL,
        `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )";
    $conn->exec($sqlUsers);

    // 4. Tambah Akun Admin jika belum ada
    $stmt = $conn->query("SELECT COUNT(*) FROM `users` WHERE `username` = 'admin'");
    if ($stmt->fetchColumn() == 0) {
        $passwordHash = password_hash('password123', PASSWORD_BCRYPT);
        $stmtInsert = $conn->prepare("INSERT INTO `users` (`username`, `password`, `nama_lengkap`) VALUES ('admin', :pass, 'Administrator')");
        $stmtInsert->execute(['pass' => $passwordHash]);
    }

    // 5. Buat Tabel Produk
    $sqlProduk = "CREATE TABLE IF NOT EXISTS `produk` (
        `id` INT AUTO_INCREMENT PRIMARY KEY,
        `nama_produk` VARCHAR(100) NOT NULL,
        `kategori` VARCHAR(50) NOT NULL,
        `harga` DECIMAL(12,2) NOT NULL,
        `stok` INT NOT NULL,
        `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )";
    $conn->exec($sqlProduk);

    echo "<div style='font-family: sans-serif; padding: 20px; background: #dcfce7; color: #166534; border-radius: 8px;'>";
    echo "<h2>✅ Database & Tabel Berhasil Dibuat Otomatis!</h2>";
    echo "<p>Akun login default:</p>";
    echo "<ul><li>Username: <b>admin</b></li><li>Password: <b>password123</b></li></ul>";
    echo "<a href='auth/login.php' style='display:inline-block; padding:10px 15px; background:#166534; color:#fff; text-decoration:none; border-radius:5px;'>Ke Halaman Login &rarr;</a>";
    echo "</div>";
} catch (PDOException $e) {
    echo "<div style='font-family: sans-serif; padding: 20px; background: #fee2e2; color: #991b1b; border-radius: 8px;'>";
    echo "<h2>❌ Gagal Membuat Database:</h2>";
    echo "<p>" . $e->getMessage() . "</p>";
    echo "</div>";
}
